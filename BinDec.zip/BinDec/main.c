#include <stdio.h>
#include <stdlib.h>
#include <math.h> //somente para uso de expoente - pow(base,expoente)

int main(){
    int Escolha, Base10, Base2;
    int I, J, K, Aux, Comp;
    int Invertido[100];
    int Resto, Dividendo=0;
    int Cont=0;
    int Digitos=0;
    int Resultado=0;
    printf("Esta calculadora converte numeros inteiros entre os sistemas binario e decimal.\n");
    printf("Os numeros informados devem ser inteiros e positivos.\n\n");
    printf("Caso seja inserido numero na Base 10, este sera convertido para Base 2.\n");
    printf("Caso seja inserido numero na Base 2, este sera convertido para Base 10.\n\n");
    printf("Digite 1 para converter decimal para binario e 2 para o contrario: ");
    scanf("%d",&Escolha);

    if(Escolha==1){
        printf("\nConversao de Base 10 para Base 2: \n");
        printf("Digite o valor a ser convertido: ");
        scanf("%d",&Base10);
        Dividendo=Base10;
        while(Dividendo>=2){
            Resto=Dividendo%2;
            Dividendo=Dividendo/2;
            Invertido[Cont]=Resto;
            Cont=Cont+1;
        }
        Invertido[Cont]=Dividendo;
        for (J=0, K=Cont; J<K; J++, K--){
            Aux = Invertido[J];
            Invertido[J] = Invertido[K];
            Invertido[K] = Aux;
        }
        printf("\nO valor no sistema binario e: ");
        for (I=0;I<=(Cont);I++){
            printf("%d", Invertido[I]);
        }
    }else if(Escolha==2){
        printf("\nConversao de Base 2 para Base 10: \n");
        printf("Digite o valor a ser convertido: ");
        scanf("%d",&Base2);
        if (Base2==0){
            Resultado=0;
            printf("\nZero em decimal e zero.");
        }else{
            Comp=Base2;
            while(Comp!=0){
                Resto=Comp%2;
                Resultado=Resultado+(Resto*pow(2,Digitos));
                Digitos=Digitos+1;
                Comp=Comp/10;
            }
            printf("\nO valor no sistema decimal e: %d",Resultado);
        }
    }else{
        printf("A opcao nao existe. Calculadora desligada.");
    }
    return 0;
}
